// Fungsi untuk mengambil dan menampilkan data JSON
function fetchData() {
    const url = 'https://script.google.com/macros/s/AKfycbwHUZgtEx_U08QlkFg_3lfEUj9WZMZAgL9MoEKPNu0DzYWEJROToAfxN4LX-r-1q7a7/exec';
    const msgBox = document.getElementById('msg_box');

    fetch(url)
        .then(response => response.json())
        .then(data => {
            data.forEach(item => {
                const card = document.createElement('div');
                card.classList.add('card', 'mb-3');

                const cardBody = document.createElement('div');
                cardBody.classList.add('card-body');

                cardBody.innerHTML = `
                    <h4 class="card-title">${item.nama}</h4>
                    <p class="card-text">Kehadiran: ${item.status}</p>
                    <span class="card-text">${item.comment}</span>
                    `;

                card.appendChild(cardBody);
                msgBox.appendChild(card);
            });
        })
        .catch(error => {
            console.error('Error fetching data:', error);
        });

}

// Fungsi untuk memeriksa data baru secara berkala
function checkForNewData() {
}

// Panggil fungsi fetchData saat halaman selesai dimuat
window.onload = fetchData;

// Panggil fungsi checkForNewData setiap 1 detik
setInterval(checkForNewData, 1000);
