// copy start
const rek1 = document.getElementById("rek1");
const salin1 = document.getElementById("salin1");

salin1.onclick = () => {
  rek1.select();
  rek1.setSelectionRange(0, 99999); // Selects the text inside the input
  document.execCommand("copy"); // Simply copies the selected text to clipboard
  alert("Alamat pengiriman berhasil disalin");
  /*  Swal.fire({
    icon: "success",
    title: "Nomor Rekening Berhasil di Salin",
    showConfirmButton: false,
    timer: 1000,
   }); */
};
// copy end

// copy start
const rek2 = document.getElementById("rek2");
const salin2 = document.getElementById("salin2");

salin2.onclick = () => {
  rek2.select();
  rek2.setSelectionRange(0, 99999); // Selects the text inside the input
  document.execCommand("copy"); // Simply copies the selected text to clipboard
  alert("Nomor rekening telah disalin");
  /* Swal.fire({
    icon: "success",
    title: "Nomor Rekening Berhasil di Salin",
    showConfirmButton: false,
    timer: 1000,
  }); */
};
// copy end